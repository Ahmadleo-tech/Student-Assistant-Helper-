import Health_Track as ht
import Derive_manage as dm
import Create_Notes as cn
import Search_Engine as se
import Quiz_gen as qg

def main():
    print("Welcome to the Student AI Program!")
    print("Please select an option from the menu below:")
    print("1. Create Notes")
    print("2. Derive Manager")
    print("3. Search Engine")
    print("4. Health Track")
    print("5. Take Quiz")
    print("6. Exit")

    try:
        choice = int(input("Enter your choice: "))
    except ValueError:
        print("Invalid input. Please enter a number between 1 and 6.")
        return

    if choice == 1:
        app = cn.NoteTakingApp()
        app.create_notes()
    elif choice == 2:
        dm.main1()
    elif choice == 3:
        se.main2()
    elif choice == 4:
        ht.main3()
    elif choice == 5:
        qg.main4()
    elif choice == 6:
        print("Successfully exited! Have a great day!")
    else:
        print("Invalid choice. Please enter a number between 1 and 6.")

if __name__ == "__main__":
    main()